<?php
/**
 * Properties English Lexicon Entries for Marvin
 *
 * @package marvin
 * @subpackage lexicon
 */
