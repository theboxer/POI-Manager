<?php
/**
 * @package marvin
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/marvinsimpleobject.class.php');
class MarvinSimpleObject_mysql extends MarvinSimpleObject {}
?>