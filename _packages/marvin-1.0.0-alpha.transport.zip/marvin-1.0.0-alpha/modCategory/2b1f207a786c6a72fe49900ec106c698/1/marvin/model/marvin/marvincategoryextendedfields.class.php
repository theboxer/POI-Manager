<?php
/**
 * @property string $icon
 * @property string $color
 * @property int $category
 * @property MarvinCategory $Category
 *
 * @package marvin
 */
class MarvinCategoryExtendedFields extends xPDOSimpleObject {}
