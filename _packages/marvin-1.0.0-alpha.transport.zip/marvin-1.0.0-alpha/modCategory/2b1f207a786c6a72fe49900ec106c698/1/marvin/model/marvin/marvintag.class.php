<?php
/**
 * @property string $tag
 * @property string $context
 * @property modContext $Context
 * @property MarvinLocationTag $TagLocations
 *
 * @package marvin
 */
class MarvinTag extends xPDOSimpleObject {}
