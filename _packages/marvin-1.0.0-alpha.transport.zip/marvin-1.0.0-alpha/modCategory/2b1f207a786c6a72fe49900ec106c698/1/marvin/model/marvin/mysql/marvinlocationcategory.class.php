<?php
/**
 * @package marvin
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/marvinlocationcategory.class.php');
class MarvinLocationCategory_mysql extends MarvinLocationCategory {}
?>