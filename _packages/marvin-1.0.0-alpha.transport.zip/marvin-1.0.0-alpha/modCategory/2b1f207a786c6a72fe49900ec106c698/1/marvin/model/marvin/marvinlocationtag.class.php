<?php
/**
 * @property int $location
 * @property int $tag
 * @property MarvinLocation $Location
 * @property MarvinTag $Tag
 *
 * @package marvin
 */
class MarvinLocationTag extends xPDOObject {}
