=====================
     POI Manager
      0.1.0 alpha

      Jan Peca
  pecajan@gmail.com

    Supported by
    ------------
   COEX CZ, s.r.o.
 http://www.coex.cz
    info@coex.cz
=====================