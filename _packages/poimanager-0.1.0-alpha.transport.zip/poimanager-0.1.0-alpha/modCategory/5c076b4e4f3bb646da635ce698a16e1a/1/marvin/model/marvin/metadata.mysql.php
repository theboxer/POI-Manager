<?php

$xpdo_meta_map = array (
  'modResource' => 
  array (
    0 => 'MarvinCategory',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'MarvinCategoryExtendedFields',
    1 => 'MarvinSimpleObject',
    2 => 'MarvinTag',
    3 => 'MarvinFieldValue',
  ),
  'MarvinSimpleObject' => 
  array (
    0 => 'MarvinLocation',
    1 => 'MarvinFeedback',
    2 => 'MarvinComment',
    3 => 'MarvinPhoto',
    4 => 'MarvinLocationType',
    5 => 'MarvinField',
  ),
  'xPDOObject' => 
  array (
    0 => 'MarvinLocationTag',
    1 => 'MarvinLocationCategory',
  ),
);