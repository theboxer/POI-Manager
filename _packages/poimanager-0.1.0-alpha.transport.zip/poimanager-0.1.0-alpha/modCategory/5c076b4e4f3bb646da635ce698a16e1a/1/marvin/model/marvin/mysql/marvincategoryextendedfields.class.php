<?php
/**
 * @package marvin
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/marvincategoryextendedfields.class.php');
class MarvinCategoryExtendedFields_mysql extends MarvinCategoryExtendedFields {}
?>