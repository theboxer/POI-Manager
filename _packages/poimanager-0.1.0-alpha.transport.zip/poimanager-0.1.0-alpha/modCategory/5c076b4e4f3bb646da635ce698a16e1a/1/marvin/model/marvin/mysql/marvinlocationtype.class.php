<?php
/**
 * @package marvin
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/marvinlocationtype.class.php');
class MarvinLocationType_mysql extends MarvinLocationType {}
?>