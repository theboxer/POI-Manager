<?php
require_once 'marvinsimpleobject.class.php';
/**
 * @property string $name
 * @property string $description
 * @property MarvinLocation $Locations
 * @property MarvinField $Fields
 *
 * @package marvin
 */
class MarvinLocationType extends MarvinSimpleObject {}
