<?php
/**
 * @property int $location
 * @property int category
 * @property MarvinLocation $Location
 * @property MarvinCategory $Category
 *
 * @package marvin
 */
class MarvinLocationCategory extends xPDOObject {}
