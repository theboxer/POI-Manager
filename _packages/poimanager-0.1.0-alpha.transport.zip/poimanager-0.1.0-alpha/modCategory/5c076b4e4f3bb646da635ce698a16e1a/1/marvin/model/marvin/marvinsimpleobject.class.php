<?php
/**
 * @property int $created
 * @property int $updated
 * @property int $deleted
 * @property int $updated_by
 * @property modUser $Updated_by
 *
 *
 * @package marvin
 */
class MarvinSimpleObject extends xPDOSimpleObject {}
